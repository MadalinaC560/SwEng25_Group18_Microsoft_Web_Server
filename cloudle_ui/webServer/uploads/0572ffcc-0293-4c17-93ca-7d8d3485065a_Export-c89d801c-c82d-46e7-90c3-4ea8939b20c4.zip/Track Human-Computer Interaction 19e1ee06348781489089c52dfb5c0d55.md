# Track: Human-Computer Interaction

*Sponsored by Intercom – Prize: **€2,000** ⚡*

**Just as Intercom is redefining how people engage with AI in customer service, we challenge you to go beyond traditional interfaces and reimagine how humans interact with digital systems at large.** Whether you’re revolutionizing patient care in hospitals 🏥, transforming fitness into a VR adventure 🏃‍♀️, or creating mind-bending entertainment experiences 🎮—this track is all about building immersive, intuitive, and deeply human-centric solutions.

---

## **Why Human-Computer Interaction?** ✨

Today’s world craves **immersive, intuitive, and user-centric** experiences. Screens and keyboards are no longer enough—we’re blending physical and digital realms to create seamless interfaces that **enrich** daily life. Whether it’s **voice assistants** that learn our habits, **VR games** that defy reality, or **brain-computer interfaces** that respond to our thoughts, HCI holds the key to transforming healthcare, entertainment, fitness, and learning. **Your mission:** design mind-blowing ways for humans to engage with technology.

---

## **Four Key Domains to Explore** 🌐

### **1. Healthcare 🏥**

- **AR for Surgery & Training:** Overlay critical medical data onto surgeons’ fields of view.
- **Conversational AI & BCIs:** Offer real-time support for patients, including those with limited mobility.**Project Idea:** *“See-Through Surgeon”* – a mixed-reality headset that superimposes CT scans over a patient, enhancing surgical accuracy and providing interactive checklists.

### **2. Entertainment 🎮**

- **Mixed-Reality Experiences:** E.g., location-based AR games or massive virtual concerts.
- **AI-Driven Interactive Storytelling:** Let players shape the narrative in real time.**Project Idea:** *“EmoGame”* – an AI-driven platform that detects facial expressions or heart rate to alter game difficulty and storyline, amping up immersion.

### **3. Fitness 🏃**

- **Gamified Workouts:** Turn exercise into epic quests with VR or AR scenarios.
- **Smart Coaching:** Use computer vision to analyze form, track progress, and deliver personalized tips.**Project Idea:** *“Run ‘n’ Raid”* – a fitness app that transforms your daily jog into a monster-hunting AR adventure, rewarding you with coins for hitting intervals or sprints.

### **4. Learning 🎓**

- **Immersive Classrooms:** Experience historical eras or scientific phenomena via VR.
- **AI-Powered Tutoring:** Offer conversational, adaptive feedback in real-time.**Project Idea:** *“TutorVerse”* – an AR/VR environment where students explore math or science concepts by interacting with 3D models, guided by an AI mentor.

---

## **Inspiration from Past HCI Breakthroughs** 🚀

- **AR Surgery Aids:** Surgeons already use headsets that “see through” tissues to reduce errors.
- **VR Fitness Games:** Apps like Supernatural combine music, movement, and VR to make workouts fun.
- **AI-Driven Education:** Personalized tutoring platforms adjust lessons based on user performance and engagement.

What’s next? **You** decide. Maybe a voice-activated therapy companion for mental health or a brainwave-controlled playlist that matches your mood. Let your creativity run wild!

---

## **Tips & Metrics for Success** ✅

1. **Delight the User:** If it feels cumbersome, it’s not HCI. Aim for interfaces that feel natural and effortless.
2. **Real-World Impact:** Show how your solution saves time, aids recovery, boosts engagement, or spurs faster learning.
3. **Scalability & Accessibility:** Consider users with varying abilities. A truly human-centric design is inclusive by default.

---

## **Join the Revolution** 💡

From Intercom’s earliest days helping businesses connect with customers, we’ve championed user-focused, **AI-driven** innovation. Now we want **you** to push the boundaries of how humans and computers interact. Whether it’s a mind-controlled to-do list or an AR solution for collaborative surgery—**this is your chance to reshape the future of HCI**.