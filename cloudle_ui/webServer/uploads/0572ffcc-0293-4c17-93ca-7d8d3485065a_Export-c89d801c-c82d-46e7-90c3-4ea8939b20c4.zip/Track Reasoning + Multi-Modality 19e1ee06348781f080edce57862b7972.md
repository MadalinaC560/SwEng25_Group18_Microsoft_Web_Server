# Track: Reasoning + Multi-Modality

> Core Theme: “AI that understands more than just text.”
> 
> 
> We encourage you to build hacks involving **multiple data modalities**—combining text, images, speech, video, sensor data, and more. Another key focus is **reasoning and intelligence**: your project should do something clever with the data, not just display it. That might mean drawing inferences, making decisions, or explaining *why* something is happening—for example, analyzing an image and answering in-depth questions, not just labeling it.
> 

---

### **Reasoning Explanation** 🤔

We can think of **reasoning** through two cognitive systems:

- **System 1:** Quick, automatic, and instinctive
- **System 2:** Slow, methodical, and process-driven

Some tasks, like “What’s the capital of Tuvalu?” rely on System 1 (straight facts). But for complex puzzles - like a sudoku or an IMO problem - System 2 is your best friend, iterating step-by-step until it finds a solution. **That** is the essence of reasoning.

### **Quick Background on Reasoning** 🧩

OpenAI’s “o-series” models have evolved beyond mere language generation. They employ **chain-of-thought** logic—thinking internally before responding:

- **Codenamed Strawberry -** Optimised for lightweight use, excellent for textual reasoning (for visual tasks, check out the o1 series).
- **Deep Research -** An autonomous agent in ChatGPT that uses the **ReAct** paradigm (**Reason + Act**) to break down multi-step investigations—searching, reading, reasoning, and refining—to deliver more reliable, fact-based outputs with minimal fabrication.

---

## **Embracing Multimodality** 🎨

Multimodality blends different inputs—**text**, **images**, **audio**, etc.—to create richer, more interactive experiences. Consider these groundbreaking examples:

- [**Sora**](https://openai.com/sora/): Text-to-video model for turning words into dynamic visuals
- [**Whisper**](https://openai.com/index/whisper/): Leading speech recognition for voice-based applications
- [**DALL·E 3**](https://openai.com/index/dall-e-3/): Generates vivid images from text prompts

---

## **Newest Developments: 12 Days of Christmas + Dev Day** 🎄

- [**Realtime API](https://github.com/openai/openai-realtime-solar-system):** Eliminate juggling separate APIs for speech input (Whisper), text processing (GPT 4o), and TTS. Check out the DevDay24 demo by our mentor [***Katia Gil Guzman**](https://www.youtube.com/watch?v=mM8KhTxwPgs).*
- [**Structured Outputs Samples](https://github.com/openai/openai-structured-outputs-samples/tree/main?tab=readme-ov-file):** Learn how to get JSON or other machine-readable output from your AI.
- **Developer Fun with o1 + New Tools:** Head to [**openai.com/index/o1-and-new-tools-for-developers**](https://openai.com/index/o1-and-new-tools-for-developers/) for the latest.
- [**12 Days of Christmas](https://openai.com/12-days/):** Featuring voice, video, “Santa mode,” project inspirations, and Apple Intelligence.

---

## **Inspirational Hackathon Projects** 🚀

Below are standout projects that fuse **reasoning** and **multimodality** to solve real-world problems:

- [**Baymax: Tree Hacks 2024**](https://devpost.com/software/baymax-your-personal-healthcare-companion)
    
    An AI-powered robotic arm that assists those in need by tracking facial cues and delivering food in a humane, personalised way.
    
- [**Show And Tell: TreeHacks 2024**](https://devpost.com/software/show-and-tell-capturing-emotion-in-sign-language)
    
    Bridges the communication gap between deaf and hearing communities by translating ASL into spoken English using vision and language models.
    
- [**ShaScam: TreeHacks 2024**](https://devpost.com/software/shascam)
    
    Protects vulnerable populations from scam calls by converting speech to text and applying advanced reasoning to identify phishing patterns—sometimes even engaging scammers with an AI voice!
    
- [**Dispatch AI: AI Hacks Berkeley 2024**](https://devpost.com/software/dispatch-ai)
    
    Reimagines emergency response by integrating empathetic AI into 911 call centers. It analyzes speech, detects emotions, and aggregates call data in real time—all while keeping a human in the loop.
    
- [**llm2graph: TreeHacks 2024**](Track%20Reasoning%20+%20Multi-Modality%2019e1ee06348781f080edce57862b7972.md)
    
    Leverages an LLM’s reasoning to build a dynamic, real-time knowledge graph that continuously updates as new info arrives. Ideal for data retrieval in healthcare, law, or finance.
    
- [**Mindscape: MIT Hacks 2024**](https://ballot.hackmit.org/project/mmnum-zajod-mfhgr-bcnyu)
    
    Turns 2D MRI scans into 3D color maps to aid precise diagnosis and personalized treatments.
    

**Bonus**

[**OpenAI Operator w/ Replit Agent**](https://x.com/LamarDealMaker/status/1890779656128696536) — watch two AI agents team up, exchange credentials, and start testing an app, blending automation, collaboration, and reasoning.

[**TreeHacks 2025](https://treehacks-2025.devpost.com/submissions/search?utf8=%E2%9C%93&prize_filter%5Bprizes%5D%5B%5D=83832)** — take a look through all of this year’s Treehacks project that used OpenAI APIs for more inspiration.

---

### **Companies Using Multimodal Video Analysis** 📹

- [**Traces**](http://traces.ai/) (YC S19)
    
    Automates video analysis to identify people, license plates, or events—combining vision with reasoning.
    
- [**Figure Robots**](https://x.com/Figure_robot/status/1858876300691468579)
    
    Builds humanoid robots with speech capabilities and a 360° camera system for assembly line work.
    
- [**Reality Defender**](http://realitydefender.com/) (YC W22)
    
    Real-time detection of AI-generated audio, video, images, and documents.
    

---

## **Broader Ideas to Inspire You** ✨

- **Community Policy Simulator**
    
    Create virtual societies of AI agents (shopkeepers, customers, politicians) to test social/economic policies—like **SimCity powered entirely by AI**.
    
- **Self-Taught Reasoner (STaR)**
    
    Models that generate their own challenging problems, learning through self-reflection and synthetic data creation.
    
- **Real-Time Wearable AI Assistant**
    
    Analyzes live video from a wearable camera and whispers real-time insights—your digital co-pilot for everyday life!
    
- **Scenario Planning Tool**
    
    Feeds on maps, charts, and textual reports to project outcomes or policy advice, bridging visual analytics and language-based reasoning.
    

---

## **More Resources** 🔧

- [**Hugging Face](https://huggingface.co/)** The HF Transformers Agent automates tasks by chaining models.
- [**LangChain](https://www.langchain.com/)** Chains LLM reasoning with various modalities—e.g., image captioning → LLM, or vice versa.
- [**Auto-GPT](https://github.com/antony0596/auto-gpt#:~:text=Auto,what%20is%20possible%20with%20AI)** An open-source, autonomous GPT-4 agent that iterates on its own outputs to accomplish goals.
- [**Runway ML](https://runwayml.com/)** Democratizes creative AI for video editing and generative art.