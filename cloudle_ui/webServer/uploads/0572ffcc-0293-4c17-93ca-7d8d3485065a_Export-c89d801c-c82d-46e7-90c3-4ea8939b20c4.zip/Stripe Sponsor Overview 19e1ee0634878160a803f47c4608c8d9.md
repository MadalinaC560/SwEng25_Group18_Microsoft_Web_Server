# Stripe Sponsor Overview

[Fintech 2.0 - *Sponsored by Stripe:* **€2,000**](Fintech%202%200%20-%20Sponsored%20by%20Stripe%20%E2%82%AC2,000%2019e1ee06348781ff9e80f0765f4409d4.md)