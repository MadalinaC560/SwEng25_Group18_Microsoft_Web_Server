# Intercom - Human Computer Interaction (& Rails)

Created: February 18, 2025 11:26 PM

![image.png](image%203.png)

We are thrilled to partner with [**Intercom](https://www.intercom.com/) -** Ireland’s very own homegrown unicorn and an AI-first customer service platform. Founded by [Eoghan](https://www.intercom.com/about/eoghan-mccabe), [Des](https://www.intercom.com/about/des-traynor) and [Ciaran](https://www.intercom.com/about/ciaran-lee), and David. 

---

## Partner Tracks

### **1. Track: Human-Computer Interaction**

*Sponsored by Intercom – Prize: **€2,000 +** Dinner with **Intercom’s Team***

Design and implement natural, intuitive interactions between humans and technology. This is your chance to demonstrate how seamless design meets innovative tech.

[<< MORE INFO ON THIS TRACK >>](Track%20Human-Computer%20Interaction%2019e1ee06348781489089c52dfb5c0d55.md)

---

### **2. Challenge: Best ‘Built On Rails’ Project**

*Sponsored by Intercom – Prize: **€1,000***

Celebrate Intercom’s founding story by harnessing Ruby on Rails to build something truly groundbreaking. Tap into the power of Rails to bring innovation to life.

[Explore the Challenge »](Challenge%20Best%20%E2%80%98Built%20On%20Rails%E2%80%99%20Project%2019e1ee063487816f9e95eaf7cad74e8c.md)

---

## 🤝 Mentorship & Support

Need guidance? Intercom experts will be on-hand in person to help you refine your ideas and overcome challenges:

- **Saturday:** 12 PM - 6 PM
- **Sunday:** 9 AM - 3 PM

Note: Ciaran Lee and Des Traynor, the two co-founders of Hack Ireland, will be joining us and a Intercom mentor will be spending the night at DogPatch! Incredible!

---

## Recruiting Opportunities at Intercom

Check out the dedicated Hack Ireland x Intercom page:

[Intercom HackIreland 2025](https://www.intercom.com/intercom-hackireland-2025)

---

**Let’s hack the future together at Hack Ireland!** ✨

[Track: Human-Computer Interaction (1)](Track%20Human-Computer%20Interaction%20(1)%2019e1ee063487817ea5cae9583d4ef3b1.md)

[Challenge: Best ‘Built On Rails’ Project ](Challenge%20Best%20%E2%80%98Built%20On%20Rails%E2%80%99%20Project%2019e1ee063487818fbd23f21e193b650f.md)

[Learn More About Intercom and Recruiting Opportunities (1)](Learn%20More%20About%20Intercom%20and%20Recruiting%20Opportuni%2019e1ee0634878146983edf8f7db5d6e8.md)