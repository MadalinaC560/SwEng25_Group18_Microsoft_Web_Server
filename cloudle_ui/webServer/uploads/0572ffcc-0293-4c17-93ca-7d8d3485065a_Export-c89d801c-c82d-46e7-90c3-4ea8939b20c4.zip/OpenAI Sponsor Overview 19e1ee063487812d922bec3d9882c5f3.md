# OpenAI Sponsor Overview

[Reasoning + Multi-Modality - *Sponsored by OpenAI:* **€2,000**](Reasoning%20+%20Multi-Modality%20-%20Sponsored%20by%20OpenAI%20%E2%82%AC%2019e1ee063487819fac69d4c30d06e476.md)