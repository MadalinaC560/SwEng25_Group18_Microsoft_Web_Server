# Hack Ireland 2025: Welcome Packet

---

*You're now part of Ireland's largest student hackathon – 150 of the country's most talented builders coming together to push the boundaries of what's possible. For us, Hack Ireland is not about a single weekend of coding – it's about creating a culture that encourages students to think bigger and build fun, ambitious projects year-round.*

*Over the next 30 hours, you'll be experimenting, forming new friendships, and bringing bold ideas to life. €25,000 in prizes. Infinite possibilities. Time to build something incredible.*

*Let’s hack!*

*— The Hack Ireland Team* 

## **📍Time & Location 📍**

---

Hack Ireland 2025 takes place **February 22–23**, from **8:30 AM Saturday** to **7 PM Sunday** at **Dogpatch Labs**, The CHQ Building, Custom House Quay, North Wall, Dublin. We’re allowing students to stay overnight!

> **Venue Entrance:** Head to the ground floor of the CHQ building - the Dogpatch entrance is opposite Starbucks.
> 

**Key point here:** **We won’t accept any arrivals after 9:30 AM** since our kickoff ceremony starts at **9:45 AM** with a keynote from [**Des Traynor**](https://ie.linkedin.com/in/destraynor), who has to leave at **10:30 AM**. 

[https://www.google.com/maps/place/Dogpatch+Labs/@53.3487,-6.2486,17z/data=](https://www.google.com/maps/place/Dogpatch+Labs/@53.3487,-6.2486,17z/data=)

**Join our WhatsApp community**: [**LINK**](https://chat.whatsapp.com/Cn92IyfpBng7nJxiSEpBxM)

**Join our Event Discord**: [**LINK**](https://discord.gg/eJTNQBkGJE)

## 📦 Packing List 📦

---

**Make sure you bring**:

- **Government-issued ID** or **University ID**
- **Smartphones/Tablets & Chargers** *(for use in your hack)*
- **Personal Hardware** *(VR headsets, Raspberry Pi, Motion Trackers, etc.)*
- **Sleeping Gear** *(sleeping bag, pillow, blanket)*
    
    > We have a resting area, but cannot provide sleeping materials.
    > 
- A **Change of Clothes**
- A **Sweater/Jacket** *(it can get chilly!)*
- **Toiletries** *(deodorant, toothbrush, toothpaste, etc.)*
    
    > Only 3 showers are available—plan accordingly.
    > 
- **Headphones/Earbuds**
- **Medication** *(if needed)*
- **Refillable Water Bottle***(water fountains available on-site)*

## 📅 Schedule (subject to change) 📅

---

### **Saturday**

- **08:30** – Registration Opens (Doors open to hackers)
- **09:30** – Registration Closes( Doors lock—see above for why we’re strict)
- **09:45** – Opening Ceremony (Kickoff with [**Des Traynor**](https://www.linkedin.com/in/destraynor/?originalSubdomain=ie))
- **11:00** – Hacking Begins + Late Check In Opens
- **12:00** – Mentors Available
- **13:00** – Lunch
- **14:00** – Hacking Continues & Workshops Begin
- **18:00** – Workshops & Mentorship End
- **19:00** – Dinner (Sponsored by [**EF**](https://www.joinef.com/))

### **Sunday**

- **00:00** – Snack Break
- **01:30** – Late-Night Pizza
- **08:00** – Breakfast
- **09:00** – Mentors Available Again
- **12:00** – Lunch (Sponsored by [**Founders**](https://www.joinfounders.co/about))
- **14:00** – Project Submission Deadline
- **15:00** – Demos & Judging
- **18:00** – Awards & Closing Ceremony

## 💲Tracks & Prizes💲

---

### Overall Placement Prizes

### **Grand Prize - €6k**

   *+ €2k OpenAI Credits & 1yr ChatGPT Plus Subscription*

### **Runner Up - €3k**

   *+ €500 OpenAI Credits*

### Track Prizes

**Intercom**

- Human-Computer Interaction - €2k

    *+ Dinner with the Intercom team*

**Stripe** 

- Fintech Track - €2k

**Tines**

- Automation, Simplicity, Efficiency - €2k

**OpenAI**

- Reasoning & Multimodality - €2k

    *+ €2k OpenAI Credits & 1yr ChatGPT Plus Subscription*

### Challenges - €2k

- Intercom “Best Built on Rails” Challenge - €1k
- Patch “Best U21 Team” Prize - €1k

[🔍 Track Details 🔍](%F0%9F%94%8D%20Track%20Details%20%F0%9F%94%8D%2019e1ee06348781129c63e2d27ce6b8a0.csv)

### 💡Inspiration💡

---

Get inspired by some big US hackathon!

- We have sprinkled in some very good project inspirations in each individual track.
- Watch these videos - hyper linked at project demos to creatively showcase your projects at the end!

<aside>
💡

Hack MIT 
[https://ballot.hackmit.org/gallery](https://ballot.hackmit.org/gallery?page=1) - 2024

</aside>

<aside>
💡

Hack The North 

[https://hackthenorth2024.devpost.com/project-gallery](https://hackthenorth2024.devpost.com/project-gallery) - [https://www.youtube.com/live/I5dP9mbnx4M?si=dBCn8Cru6aJBN6iA&t=4416](https://www.youtube.com/live/I5dP9mbnx4M?si=dBCn8Cru6aJBN6iA&t=4416) 

</aside>

<aside>
💡

Cal Hacks
[https://cal-hacks-11-0.devpost.com/project-gallery](https://cal-hacks-11-0.devpost.com/project-gallery) 

</aside>

<aside>
💡

Tree Hacks

[https://treehacks-2025.devpost.com/project-gallery](https://treehacks-2025.devpost.com/project-gallery) 

[https://treehacks-2024.devpost.com/project-gallery](https://treehacks-2024.devpost.com/project-gallery)

</aside>

<aside>
💡

https://www.nosu.io/ - generate hackathon-winning ideas (recently VC backed - founder won 21x hackathons!)

</aside>

<aside>
💡

[How to Win EVERY Hackathon (from a Top 50 Hacker)](https://www.youtube.com/watch?v=JWxcEL4mg_Q&pp=ygUWaG93IHRvIHdpbiBhIGhhY2thdGhvbg%3D%3D) - Duke Student 

</aside>

### 🔨 Resources 🔨

---

- **Dogpatch Labs Wi-Fi**
    - **Network:** `DOGPATCH` **Password:** `Community25!`
    - **Network:** `DOGPATCH-GUEST` **Password:** `Welcome2DPL25!`*(Exact details will also be available on-site!)*
- **Free ChatGPT Plus (2 Weeks)**
    
    **To Redeem:** Create (or use your existing) OpenAI account with the **same email** you used to register for Hack Ireland. If you don’t set this up before **Friday**, we won’t be able to secure access for you.
    
- **$20 OpenAI Credits**
    
    These will also be sent to the **same email** address. Follow the same steps above to ensure you receive them.
    

## 🏆 Project Submission & Judging 🏆

---

### **Submissions:** Project submissions will be made on our [Devpost](https://devpost.com/) (link coming soon) with all details about your hack, your team, and any prize categories you’re aiming for (including sponsor challenges).

**Prize Eligibility**: You must be **physically present** during judging to demo your project. Judging takes place at our expo, where judges and sponsors will visit each team. You’ll have **up to 5 minutes** to present—keep it snappy, and show the actual project, not just slides! Hackathons focus on what you build and learn, even if it’s unfinished.

After judging, we’ll announce top teams at the closing ceremony, and they’ll demo for everyone.

### Judging is based on three criteria:

1. **Technical Quality**
    - The project should demonstrate clean, well-structured, and efficient code that follows best practices. Judges will look for proper use of tools and design patterns, as well as code readability and maintainability.
2. **Production Readiness / Polish**
    - The user experience should feel smooth and intuitive, whether it's a web app, mobile app, CLI tool, or another interface. Attention to detail, responsiveness, error handling, and overall usability will be considered, ensuring the solution feels like a finished product.
3. **Creativity**
    - The project should bring fresh ideas to the table, whether through innovative problem-solving, an elegant technical implementation, or a visually striking and well-crafted design. Judges will assess originality, uniqueness, and the overall wow factor of the build.

*We’ll have more details on the judging process later! There will be 2 rounds of judging! **Stay Tuned.***

### 🏟 Venue Details 🏟

---

### **Best Ways to Get to Dogpatch Labs**

**Light Rail (Luas)**

- Luas Red Line – Disembark at George’s Dock. It’s just a 1-minute walk from there to Dogpatch Labs.

**Bus**

- Routes: **14, 151, 27, 4, 60, and 7** stop nearby.
- Closest stops (all a 3-minute walk away):
    - Custom House Quay (Jurys Inn)
    - Custom House Quay
    - Jury's Inn Custom House Quay

**Train**

- DART or Commuter lines to Connolly Station.
- About a 4–5 minute walk from the station to Dogpatch Labs.

**Driving**

- We cannot support individual hackers driving to the venue.
- Drop-offs or other transport methods are encouraged.

[HACK IRELAND - GUIDE .pdf](HACK_IRELAND_-_GUIDE_.pdf)

## 🌮 Food 🍕

---

We’ve got free meals, snacks, and energy boosters through the event! Dietary restrictions? No worries—we’ve got you covered. Teams **1–19** will grab food upstairs at Urban Kitchen, while Teams **20–38** will pick up downstairs at The Vault.

Some of our meal highlights:

- **Saturday Lunch**: ~230 sandwiches
- **Saturday Dinner**: Chinese catering for ~200 people
- **Sunday 2 AM Pizza**: ~118 medium pizzas (8 slices each)
- **Sunday Brunch**: 400 sausages, 200 bacon, 200 eggs, beans, chips, toast
- **1,000 cans of Celsius:** (No Drinking Under 18!)
- Tons of coffee, pot noodles, granola bars, bread, ham, and cheese at Urban Kitchen and downstairs!

## 😴 Sleep 😴

---

We’re hosting everyone overnight! A **dedicated sleeping area** will be available at The Vault, but please **bring your own** sleeping materials. You can also sleep at your desk if you’d like.

> **IMPORTANT:** If you stay overnight, there’s no exit or re-entry after **10 PM Saturday until 7 AM Sunday**. This is for safety reasons—the area around Dogpatch can be unsafe at night. If you live nearby, feel free to head home and come back Sunday morning.
> 

## 🚭 Rules & Code of Conduct 🚭

---

**We strive for a harassment-free environment. If you experience or witness any issues, contact any of the event organizers.**

To be eligible for prizes, your team and project must follow Hack Ireland’s guidelines:

1. All team members must **check in** at Hack Ireland and wear the official badge.
2. At least one team member must be **physically present** to demo on Sunday.
3. All building/coding must happen **during hacking hours** (11 AM Saturday, Feb. 22 – 2 PM Sunday, Feb. 23).
    - Planning and ideation beforehand is fine (and encouraged!)—just no coding until hacking starts.
4. **No vaping/smoking inside**. If you do, you will receive a **€500 fine**, immediate **removal**, and a **ban** from future Hack Ireland events.

## 🏥 First Aid & Medical Support 🏥

---

We have first-aid support **on-site** throughout the event. If you need any medical assistance, don’t hesitate to reach out:

- **Tim Farrelly** (Organizer & Supervisor): `083 455 1238`
- **Ruari Forde** (First Aid Officer & Fire Warden): `087 277 9099`

For accessibility accommodations or special needs, please **email us** at: `team@hackireland.com`

## 🔞 Under 18 Form 🔞

---

### **If you are under 18, please do the following:**

1. **Fill out** the Under-18 Consent Form Below. 
2. **Email** the completed form to **Tim Farrelly** at **tim@hacktrinity.com**
3. **Subject Line**: `"FirstName LastName Hack Ireland Consent Form"` For example: `"Geoffrey Duan Hack Ireland Consent Form"`

[Parental Consent Form.pdf](Parental_Consent_Form.pdf)

## 📞 Contact Us 📞

---

Need help or facing an emergency? Reach out to the lead organizers via WhatsApp, or ask **anyone** in a black Hack Ireland t-shirt (plus all Dogpatch staff members)!

- **Oisín**: `+353 87 782 0595`
- **Cian**: `+353 87 385 6026`
- **Tim**: `+353 83 455 1238`
- **Geoffrey**: `+1 206 446 6210`
- **Calista**: `+353 83 899 2652`

![Screenshot 2025-02-18 at 2.40.24 p.m..png](Screenshot_2025-02-18_at_2.40.24_p.m..png)

---

---

---

[*OpenAI Sponsor Overview*](OpenAI%20Sponsor%20Overview%2019e1ee063487812d922bec3d9882c5f3.md)

[*Tines Sponsor Overview*](Tines%20Sponsor%20Overview%2019e1ee0634878156a085dd38150eb163.md)

[Intercom](Intercom%2019e1ee0634878135a500fd6dfd6671c5.md)

[*Stripe Sponsor Overview*](Stripe%20Sponsor%20Overview%2019e1ee0634878160a803f47c4608c8d9.md)