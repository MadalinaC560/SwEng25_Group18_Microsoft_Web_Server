# Learn More About Intercom and Recruiting Opportunities

**Founded in 2010, Intercom is an an Irish Unicorn ($1b+ valuation) pioneering a new era of AI-driven customer service.** 

They are also backed by leading venture capital firms, including **Bessemer Venture Partners, Kleiner Perkins, and Social Capital.**

[Intercom HackIreland 2025](https://www.intercom.com/intercom-hackireland-2025)

---

## Intercom’s Core AI Pillars ⚙️

- [**AI Agent (Fin 2.0)**](https://www.intercom.com/fin):
    
    Delivers instant, accurate, 24/7 answers that resolve up to 82% of support volume with a 50% resolution rate. Fin 2.0 outperforms competitors like Microsoft, IBM, and Zendesk by maintaining a natural conversational flow and asking the right clarifying questions.
    
- [**Copilot**](https://www.intercom.com/support-for-agents/ai-copilot):
    
    Provides always-on, proactive assistance for support agents, ensuring they have the real-time guidance and context needed to deliver exceptional service.
    
- **AI Analyst (Coming Soon):**
    
    Will offer holistic insights and actionable recommendations for support leaders, helping optimise team performance and drive continuous improvement.
    

---

**Hack Ireland participants:** Don’t miss our **exclusive 2026 recruiting link**—explore life at Intercom, discover our cutting-edge products, and learn why we’re at the forefront of AI-first customer service.