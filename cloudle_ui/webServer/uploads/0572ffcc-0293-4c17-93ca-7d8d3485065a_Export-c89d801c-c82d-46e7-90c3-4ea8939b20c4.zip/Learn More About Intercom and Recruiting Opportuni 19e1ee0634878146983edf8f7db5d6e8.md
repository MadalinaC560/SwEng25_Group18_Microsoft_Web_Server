# Learn More About Intercom and Recruiting Opportunities (1)

**Founded in 2010, Intercom is pioneering a new era of AI-driven customer service.** They are  backed by leading venture capital firms, including Bessemer Venture Partners, Kleiner Perkins, and Social Capital.

[Intercom HackIreland 2025](https://www.intercom.com/intercom-hackireland-2025)

---

## Intercom’s Core AI Pillars ⚙️

- [**AI Agent (Fin 2.0)**](https://www.intercom.com/fin):
    
    Delivers instant, accurate, 24/7 answers that resolve up to 82% of support volume with a 50% resolution rate. Fin 2.0 outperforms competitors like Microsoft, IBM, and Zendesk by maintaining a natural conversational flow and asking the right clarifying questions.
    
- [**Copilot**](https://www.intercom.com/support-for-agents/ai-copilot):
    
    Provides always-on, proactive assistance for support agents, ensuring they have the real-time guidance and context needed to deliver exceptional service.
    
- **AI Analyst (Coming Soon):**
    
    Will offer holistic insights and actionable recommendations for support leaders, helping optimize team performance and drive continuous improvement.
    

---

## Why Join Intercom? 🤝

Intercom’s culture revolves around **low drama and high impact**. As we lead an AI revolution with what we call a “dangerous ambition,” our everyday work is guided by values like **Success First, Customer Obsessed, Incredibly High Standards, Open-Mindedness, Resilience, Impatience,** and **Positivity & Optimism**. They’re woven into how we collaborate, challenge ourselves, and innovate. We’re eager to hire individuals who are passionate about our mission, fully aligned with our values, and excited to help shape the future of customer service.

---

**Hack Ireland participants:** Don’t miss our **exclusive 2026 recruiting link**—explore life at Intercom, discover our cutting-edge products, and learn why we’re at the forefront of AI-first customer service.

[Intercom HackIreland 2025](https://www.intercom.com/intercom-hackireland-2025)