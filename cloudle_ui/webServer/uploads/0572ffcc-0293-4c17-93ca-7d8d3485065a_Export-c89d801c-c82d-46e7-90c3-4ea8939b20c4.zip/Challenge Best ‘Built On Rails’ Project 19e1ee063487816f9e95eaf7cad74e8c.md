# Challenge: Best ‘Built On Rails’ Project

*Sponsored by Intercom – Prize: **€1,000** 💰*

## Intercom’s Founding Story & Ruby on Rails 🏗️

Ruby on Rails has powered Intercom’s journey from the very beginning. Co-founders [**Eoghan**](https://www.intercom.com/about/eoghan-mccabe), [**Des**](https://www.intercom.com/about/des-traynor), and [**Ciaran**](https://www.intercom.com/about/ciaran-lee) originally built **Exceptional** (later [AirBrake](https://www.airbrake.io/languages/ruby)) at their consultancy [**Contrast**](https://web.archive.org/web/20101003123509/http://www.contrast.ie/). Two key moments paved the way for Intercom:

1. **Inefficient Updates:** Mailchimp couldn’t handle user-wide updates at scale, prompting the first version of Intercom’s support bot.
2. **A Launchpad:** Selling Exceptional to Rackspace provided seed money and a direct line to early customers.

This agile and innovative use of Rails became the backbone of Intercom’s success. Now, it’s your turn to harness the same framework and build something amazing! ✨

---

## What is Ruby on Rails? 🌐

[**Ruby on Rails (RoR)**](https://rubyonrails.org/) is a powerful web framework built on [**Ruby**](https://www.ruby-lang.org/en/). It streamlines development with:

- **Rapid Iteration:** Ship features fast with Rails’ convention-driven approach. ⚡
- **Strong Community:** Access a vast ecosystem of “Gems” (libraries) and resources.
- **Proven Scale:** Industry leaders like [Shopify](https://www.shopify.com/), [GitHub](https://github.com/), and [Intercom](https://www.intercom.com/) still rely on Rails today.

Intercom also co-founded the Rails Foundation, ensuring a bright future for Rails. **Ciaran Lee** will judge this track—[hear his story](https://pioneer.app/blog/intercom-nothing-starts-finished/) and see how Rails propelled Intercom’s success.

---

## How to Get Started 🚀

1. **Learn Basic Ruby:** [Ruby Docs](https://ruby-doc.org/)
2. **Explore Rails Guides:** [Rails Getting Started](https://guides.rubyonrails.org/getting_started.html#mvc)
3. **Understand Rails Philosophy:** [Rails Doctrine](https://rubyonrails.org/doctrine)
4. **Follow Best Practices:** [Rails Guidelines](https://guides.rubyonrails.org/ruby_on_rails_guides_guidelines.html)
5. **Ruby in a Flash:** [Learn Ruby in Y Minutes](https://learnxinyminutes.com/ruby/)

---

## **Ruby on Rails’ Main Pillars 🏛️**

### **🔹 Convention Over Configuration (CoC)**

- Rails makes smart assumptions, so developers don’t need to configure everything manually. Less setup, more coding. *(Mentioned in Ruby’s Get Started + Doctrine.)*
- 🔗 Learn more: [Wikipedia](https://en.wikipedia.org/wiki/Convention_over_configuration) | [Medium Post](https://medium.com/@basemshams30/rails-unraveling-the-magic-of-convention-over-configuration-b780442495d3) | [Workify](https://www.workiy.com/technologies/ruby-rails/convention-over-configuration) | [CodeAcademy Get Started](https://www.codecademy.com/article/building-a-todolist-with-rails)

### **🔹 Don’t Repeat Yourself (DRY)**

- Rails reuses code instead of forcing developers to write the same logic repeatedly, making applications cleaner and easier to maintain.
- 🔗 Learn more: [Youtube Explanation](https://www.youtube.com/watch?v=lhXrO_ojc4k&ab_channel=MattStopaDev) | [Thoughtbot Guide](https://thoughtbot.com/ruby-science/dry.html) | [Devopedia Article](https://devopedia.org/dry-principle)

### **🔹 MVC Architecture**

- Rails **separates concerns** into three parts:
    - **Model** → Handles data and logic (Active Record).
    - **View** → Displays what the user sees.
    - **Controller** → Manages requests and responses.
- 🔗 Learn more: [Youtube Explanation](https://www.youtube.com/watch?v=pCvZtjoRq1I&ab_channel=TraversyMedia) | [Fun Take By Sitepoint](https://www.sitepoint.com/model-view-controller-mvc-architecture-rails/) | [CodeAcademy Article](https://www.codecademy.com/article/mvc)

### **🔹 Active Record (ORM for Database Management)**

- Allows developers to write database queries in Ruby instead of complex SQL, making database management easier with less code.
- 🔗 Learn more: [Youtube Explanation](https://www.youtube.com/watch?v=ZfZ8ZVxBkbY) | [Active Record Basics](https://guides.rubyonrails.org/active_record_basics.html)

---

## Project Ideas for Hack Ireland 💡

You can build *anything*—just ensure Rails is central to your backend. Rails is ideal for rapid prototyping and can easily scale to full production.

**Case Studies & Inspiration**

1. [**Doximity**](https://rubyonrails.org/docs/case-studies/doximity): Created a telehealth product used in over 63M visits during COVID.
2. [**Rails Hackathons**](https://railshackathon.com/events/2-supporting-rails/leaderboard): Check out real-world Rails code and gain tips from recent hackathon projects.
3. [**Startups on Rails**](https://blog.back4app.com/startups-using-ruby-on-rails/): Companies like Calendly and Fiverr launched with Rails—why not you?

**Gems to Explore**

- [Popular Gems](https://kinsta.com/blog/ruby-on-rails-applications/) for e-commerce, file uploads, and more.
- [Authentication Gems](https://auth0.com/blog/five-ruby-gems-for-authentication-and-authorization/) to secure your app.
- [60 Must-Haves](https://www.bacancytechnology.com/blog/ruby-on-rails-gems) for everything else.

**Suggested Builds**

- **Task Manager with Notifications**: Real-time updates with Rails + Action Cable.
- **Hackathon Matchmaker**: Match participants based on skills or interests.

For extra idea sparks, check out:

- [A16z Trends](https://a16z.com/big-ideas-in-tech-2025/)
- [YC Request for Startups](https://www.ycombinator.com/rfs)
- [Hack The North Demos](https://www.youtube.com/live/I5dP9mbnx4M?si=ZGihjtgXToq20lJs&t=4415)
- [Tree Hacks Demos](https://medium.com/@prxshetty/7-ai-ml-projects-unveiled-at-standfords-hackathon-2024-that-will-blow-your-mind-3f9a8143c93a)

---

## Project Submission Requirements 🔑

1. **Rails Must Power the Backend:**
    
    At least **50%** of your codebase should be Ruby on Rails—this includes your database layer, core logic, etc.
    
2. **Frontend Is Flexible:**
    
    Feel free to use React, Vue, or plain HTML/CSS. Just ensure Rails is at the heart of your project.
    

---

### Join the Community After Hack Ireland 🤝

Stay connected with fellow Rails enthusiasts:

- **Rails Forum:** [discuss.rubyonrails.org](https://discuss.rubyonrails.org/)
- **Rails Discord:** [discord.com/invite/d8N68BCw49](https://discord.com/invite/d8N68BCw49)

*(Feel free to ask questions here during off-mentor hours!)*

---

**Have fun, build something bold, and follow in Intercom’s footsteps—who knows where your Rails project could take you next!** ⚡