# OpenAI - Reasoning & Multimodality

Created: February 18, 2025 11:26 PM

![image.png](image.png)

[**OpenAI](https://openai.com/)** is the heavyweight champion in world-leading AI research and deployment, on a mission to ensure that artificial general intelligence (AGI) benefits all of humanity. Recently, they unveiled the mind-blowing **500 Billion Stargate Project** and integrated with Apple Intelligence and Microsoft Azure. 

We’re beyond excited to partner with OpenAI—and that means awesome perks for you, including free ChatGPT Plus subscriptions and $20 credits for everyone!

---

## Newest Product Launches + News

- [**Operator](https://openai.com/index/introducing-operator/):**
    
    An AI agent that autonomously manages repetitive tasks—like form filling and content creation—to streamline your digital workflow.
    
- [**Deep Research](https://openai.com/index/introducing-deep-research/):**
    
    Our advanced models now conduct comprehensive, multi-step web investigations, synthesizing detailed, reliable reports. Think of it as a “search-read-reason” loop on steroids!
    
- [**o3 mini](https://openai.com/index/openai-o3-mini/):**
    
    Engineered for breakthroughs in coding, mathematics, and scientific research, our new o3 mini models are here to push the limits of what AI can do.
    
- [**Paris AI Summit 24](https://openai.com/global-affairs/openai-at-the-paris-ai-action-summit/):**
    
    GPT-5 is on the horizon as OpenAI moves towards a "unified intelligence" approach, forging partnerships with Sanofi, ESCP Business School, and Orange in France!
    

---

## Partner Track: Reasoning + Multi-Modality

*Sponsored by OpenAI – Prize: **€2,000 + €2,000 in OpenAI Credits + 1-Year ChatGPT Plus Subscription***

**Where AI thinks deeper and senses more.** In this track, you’ll blend **Reasoning**—the art of combining quick insights and meticulous logic—with **Multi-Modality**—the power to process text, images, audio, and beyond. Create solutions that *truly understand*, not just respond. Whether it’s next-gen robotics, smart assistants, or data-rich simulations, this is your chance to push AI’s boundaries.

[<< MORE INFO ON THIS TRACK >>](Track%20Reasoning%20+%20Multi-Modality%2019e1ee06348781f080edce57862b7972.md)

---

## 🤝 Resources, Mentorship & Support

Fuel your projects with these essential resources:

- **Cookbook:** [OpenAI Cookbook](https://cookbook.openai.com/)
- **API Docs:** [OpenAI API Documentation](https://platform.openai.com/docs/models#o1)
- **Help Page:** [OpenAI Help](https://help.openai.com/en/)

We’re also rolling out our latest 2024 DevDay APIs and a wealth of Reasoning + Multi-Modality guides in our track document!

**Need guidance?**

Join our virtual office hours Saturday from **2 PM to 3PM AND 5 PM to 7:30 PM** via this office hours link

> [https://columbiauniversity.zoom.us/j/7713366958?pwd=xaf6GXRWb6AdadxJBpvIFmAeKWwQOZ.1&omn=92654459595](https://columbiauniversity.zoom.us/j/7713366958?pwd=xaf6GXRWb6AdadxJBpvIFmAeKWwQOZ.1&omn=92654459595)
> 

> Meeting ID: 771 336 6958
Passcode: 123456
> 

Don’t forget to hop into our [discord channel](https://discord.gg/eJTNQBkGJE)—our brilliant engineers from both the EU and SF teams are ready to answer your questions (feel free to ask personal ones too!).

---

## OpenAI in Dublin

Our European headquarters in Dublin situates us at the heart of one of Europe’s most vibrant tech communities. Here, we work hand-in-hand with regulators and local partners as we scale thoughtfully. With new roles opening in User Operations, Trust & Safety, Finance, and Engineering Support, we invite you to join us in shaping a future where AI not only understands but actively transforms how we work, learn, and live.

[Track: Reasoning + Multi-Modality](Track%20Reasoning%20+%20Multi-Modality%2019e1ee06348781f080edce57862b7972.md)