# ⚙️ Automation, ✨ Simplicity, 🚀 Efficiency

*Sponsored by Tines - 2,000*

Tines was created by Irish engineers Eoin Hinchy and Brian Kinsella after witnessing a massive breach—145 million user records stolen while they were at eBay and DocuSign. Frustrated by inflexible, complex, and brittle traditional security structures, they left their jobs and, in 2018, built a platform that’s flexible, lightweight, robust, and easy to use. Tines delivers a smart, secure workflow automation and orchestration platform for every member of your organization.

“We designed Tines to be fast, seamless, and reliable, breaking down silos and enabling teams to collaborate across a company’s technology stack to achieve shared goals. The platform provides teams with complete control, empowering users to work more efficiently and offering telemetry that promotes consistency, improves auditability, and reduces inaccuracies.”

— Eoin Hinchy

You see why we chose the name? Quite simply: **Automation, Simplicity, Efficiency**—values deeply rooted in Tines’ culture.

**Track Big Ideas 🔥**

- **Rebuild, Redesign, Reinvent:** 🔄 Transform current or outdated tools into simpler, faster, and more user-friendly systems.
- **Speed Up the Everyday:** ⏩ Build solutions that save time and simplify common tasks across industries.
- **Work Smarter, Not Harder:** 💡 Create tools that automate workflows, boost productivity, and deliver better results faster.

### **Past Automation Hackathon MVPs Worth Checking Out**

- **Stylelia (Chef “Automate for Good” Hackathon):**
    
    A tool that automatically runs static code analysis on repositories and pull requests, reducing manual tasks and helping teams adhere to best practices.
    
    [🔗 Read More](https://www.chef.io/blog/the-projects-that-wowed-our-automate-for-good-hackathon-judges)
    
- **AI-Powered Email Client (HackMIT):**
    
    An intelligent email client that automates mundane tasks—such as autofill, event scheduling, and flight check-ins—to boost productivity and save time.
    
    [🔗 View Project](https://ballot.hackmit.org/project/wfkqi-oenzw-exsyi-znsqb)
    
- **EduVid (HackHarvard):**
    
    A platform that uses AI to quickly generate high-quality educational videos, drastically simplifying and accelerating the creation of learning content.
    
    [🎥 Watch Demo](https://youtu.be/elybL6Q37Ag)
    
- **Rinc.ai (TreeHacks 2022):**
    
    A human-in-the-loop content moderation system that automates the filtering of user-generated content using custom ML models, streamlining moderation while allowing human oversight.
    
    [🔗 Discover More](https://longo.land/projects/rinc/#:~:text=We%20are%20building%20a%20human,connects%20with%20our%20moderator%20dashboard)
    
- **ConArt AI (Hack the North):**
    
    A gamified brainstorming tool that transforms sketches and text prompts into fully rendered images with AI, enabling design teams to generate and vote on new product ideas faster.
    
    [🔗 Explore Project](https://devpost.com/software/conart-ai)
    
- **Duet (Cal Hacks):**
    
    An innovative brain-computer interface that translates brainwaves into adaptive music using EEG data and machine learning, offering a unique way to communicate and experience emotions through sound.
    
    [🔗 Learn More](https://devpost.com/software/duet-0tbkxe)
    
- **So You Think You Can Do It Better? (HackHarvard):**
    
    A call to disrupt the status quo—this hackathon challenges you to take existing products, services, or systems and make them infinitely better. Log in on Devpost to see past hacks and let your innovation shine!
    
    [🔗 See All Hacks](https://hackharvard-2023.devpost.com/submissions/search?utf8=%E2%9C%93&prize_filter%5Bprizes%5D%5B%5D=69966)