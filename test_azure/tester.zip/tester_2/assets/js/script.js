document.addEventListener("DOMContentLoaded", function () {
    const button = document.getElementById("cta-button");
    const message = document.getElementById("cta-message");
  
    button.addEventListener("click", function () {
      message.style.display = "inline-block";
      setTimeout(() => {
        message.style.display = "none";
      }, 3000); // Hide message after 3 seconds
    });
  });
  